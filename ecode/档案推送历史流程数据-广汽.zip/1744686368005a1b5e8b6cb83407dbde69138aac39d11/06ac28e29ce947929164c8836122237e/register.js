
ecodeSDK.overwritePropsFnQueueMapSet('Table',{
  fn:(props)=>{
    try {
      if (isTargetPage()) {
        addDialog();
      }
    } catch (e) {
    }
  }
});

function isTargetPage(){
  const config = ecodeSDK.getCom('${appId}','config');
  if(!config){
    return false;
  }
  const searchId = config.searchId;
  const customId = ModeList.getCustomID();
  return Number(customId) ===  searchId;
}

const PushHistoryDialog = (props) => {
    const params = {
        appId: '${appId}',
        name: 'PushHistoryDialog',
        isPage: false,
        noCss: true,
        props
    }
    const NewCom = props.Com;
    return window.comsMobx ? ecodeSDK.getAsyncCom(params) : (<NewCom {...props}/>);
}

function addDialog() {
  if (document.getElementById("history-dialog")) {
    return;
  }
  const container = document.getElementById("container");
  const dialog = document.createElement("div");
  dialog.id = "history-dialog";
  container.appendChild(dialog);
  ReactDOM.render(<PushHistoryDialog/>, dialog);
}
