作者：姚礼林
日期：2024-12-10
# 功能说明
可以对历史流程进行批量档案推送
不需要停留界面一直等待，可以关闭界面，重新打开对话框后显示推送进度
![](${appRes}/file_1733878385000.png)
![](${appRes}/file_1733878413000.png)

# 配置说明
1. 编辑 config.js 文件，将 searchId 改为实际的建模查询id
2. 推送历史流程数据按钮需要自己配置，在建模中添加一个页面扩展，链接为：javascript:window.pushHistoryDialog();
![](${appRes}/file_1733878719000.png)
