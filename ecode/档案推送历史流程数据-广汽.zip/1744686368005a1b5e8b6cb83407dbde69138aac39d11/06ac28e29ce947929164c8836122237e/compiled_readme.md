"use strict";

var config = {
  searchId: 22
};
ecodeSDK.setCom('${appId}', 'config', config);
