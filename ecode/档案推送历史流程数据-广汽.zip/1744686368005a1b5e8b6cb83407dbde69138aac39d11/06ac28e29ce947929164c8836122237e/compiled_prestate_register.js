"use strict";

ecodeSDK.overwritePropsFnQueueMapSet('Table', {
  fn: function fn(props) {
    try {
      if (isTargetPage()) {
        addDialog();
      }
    } catch (e) {}
  }
});

function isTargetPage() {
  var config = ecodeSDK.getCom('${appId}', 'config');

  if (!config) {
    return false;
  }

  var searchId = config.searchId;
  var customId = ModeList.getCustomID();
  return Number(customId) === searchId;
}

var PushHistoryDialog = function PushHistoryDialog(props) {
  var params = {
    appId: '${appId}',
    name: 'PushHistoryDialog',
    isPage: false,
    noCss: true,
    props: props
  };
  var NewCom = props.Com;
  return window.comsMobx ? ecodeSDK.getAsyncCom(params) : React.createElement(NewCom, props);
};

function addDialog() {
  if (document.getElementById("history-dialog")) {
    return;
  }

  var container = document.getElementById("container");
  var dialog = document.createElement("div");
  dialog.id = "history-dialog";
  container.appendChild(dialog);
  ReactDOM.render(React.createElement(PushHistoryDialog, null), dialog);
}
