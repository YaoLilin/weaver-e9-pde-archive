"use strict";

function _instanceof(left, right) { if (right != null && typeof Symbol !== "undefined" && right[Symbol.hasInstance]) { return !!right[Symbol.hasInstance](left); } else { return left instanceof right; } }

function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!_instanceof(instance, Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

var _antd = antd,
    Modal = _antd.Modal,
    message = _antd.message,
    Progress = _antd.Progress,
    Button = _antd.Button;
var _ecCom = ecCom,
    WeaBrowser = _ecCom.WeaBrowser,
    WeaHelpfulTip = _ecCom.WeaHelpfulTip,
    WeaTools = _ecCom.WeaTools;
var callApi = WeaTools.callApi;

var PushHistoryDialog =
/*#__PURE__*/
function (_React$Component) {
  _inherits(PushHistoryDialog, _React$Component);

  function PushHistoryDialog(props) {
    var _this;

    _classCallCheck(this, PushHistoryDialog);

    _this = _possibleConstructorReturn(this, _getPrototypeOf(PushHistoryDialog).call(this, props));

    _this.handleOk = function () {
      var selectedWorkflows = _this.getSelectedWorkflows();

      if (selectedWorkflows.length === 0) {
        message.warn('请选择要推送的流程类型');
        return;
      }

      if (_this.state.pushStatus.pushing) {
        message.warn('请等待数据推送完成');
        return;
      }

      _this.setState({
        confirmLoading: true
      });

      _this.startCheckPushStatus();

      callApi('/api/secondev/archive/push-history', 'POST', {
        workflowIds: selectedWorkflows
      }).then(function (result) {
        debugger;

        if (result.success !== undefined) {
          var msg = result.message,
              success = result.success,
              hadPushData = result.hadPushData;

          if (!success) {
            message.error('推送错误：' + msg, 5);
          } else if (success && !hadPushData) {
            message.info('没有需要推送的历史数据', 5);
          } else {
            message.success('正在后台执行推送，请耐心等待', 5);
          }
        } else {
          message.success('正在后台执行推送，请耐心等待', 5);
        }
      }).catch(function (e) {
        message.error('推送异常，请联系管理员处理', 5);

        _this.setState({
          pushStatus: {
            pushing: false
          }
        });

        _this.setState({
          confirmLoading: false
        });
      });
    };

    _this.getSelectedWorkflows = function () {
      var workflowIds = [];

      _this.state.datas.forEach(function (i) {
        return workflowIds.push(i.id);
      });

      return workflowIds.join(',');
    };

    _this.handleCancel = function () {
      _this.setState({
        visible: false,
        confirmLoading: false
      });
    };

    _this.stopComfirm = function () {
      Modal.confirm({
        title: '终止确认',
        content: '确认终止推送吗？这可能导致某些数据异常',
        onOk: function onOk() {
          _this.handleStopPush();
        },
        onCancel: function onCancel() {}
      });
    };

    _this.handleStopPush = function () {
      _this.setState({
        stoping: true
      });

      callApi('/api/secondev/archive/stop-history-push', 'POST').then(function () {
        message.success('终止完成');

        _this.setState({
          stoping: false
        });

        _this.setState({
          confirmLoading: false
        });

        _this.setState({
          pushStatus: {
            pushing: false,
            totalCount: 0,
            doneCount: 0,
            failedCount: 0
          }
        });
      }).catch(function (e) {
        message.error('终止失败，请联系管理员处理', 5);

        _this.setState({
          stoping: false
        });
      });

      _this.stopCheckPushStatus();

      message.info('正在终止推送，这可能需要花费数分钟时间，请耐心等待', 5);
    };

    _this.state = {
      visible: false,
      confirmLoading: false,
      datas: [],
      pushStatus: {
        pushing: false,
        totalCount: 0,
        doneCount: 0,
        failedCount: 0
      },
      stoping: false
    };
    _this.interval = null;
    return _this;
  }

  _createClass(PushHistoryDialog, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      var _this2 = this;

      window.pushHistoryDialog = function () {
        return _this2.setState({
          visible: true
        });
      };

      this.startCheckPushStatus();
    }
  }, {
    key: "startCheckPushStatus",
    value: function startCheckPushStatus() {
      var _this3 = this;

      if (this.interval == null) {
        this.interval = setInterval(function () {
          _this3.getPushStatus();
        }, 1000);
      }
    }
  }, {
    key: "getPushStatus",
    value: function getPushStatus() {
      var _this4 = this;

      callApi('/api/secondev/archive/push-history-status', 'GET').then(function (result) {
        if (result.pushing) {
          _this4.setState({
            confirmLoading: true
          });
        } else {
          if (_this4.state.pushStatus.pushing) {
            message.success('已全部推送完成，您可以在台账中查看每条流程的推送结果', 5);
          }

          _this4.stopCheckPushStatus();

          _this4.setState({
            confirmLoading: false
          });
        }

        _this4.setState({
          pushStatus: result
        });
      }).catch(function (e) {
        _this4.stopCheckPushStatus();

        message.error('获取推送状态出错', 5);
      });
    }
  }, {
    key: "stopCheckPushStatus",
    value: function stopCheckPushStatus() {
      if (this.interval != null) {
        clearInterval(this.interval);
        this.interval = null;
      }
    }
  }, {
    key: "render",
    value: function render() {
      var _this5 = this;

      var _this$state = this.state,
          visible = _this$state.visible,
          selectedWorkflow = _this$state.selectedWorkflow,
          confirmLoading = _this$state.confirmLoading,
          datas = _this$state.datas,
          _this$state$pushStatu = _this$state.pushStatus,
          pushing = _this$state$pushStatu.pushing,
          totalCount = _this$state$pushStatu.totalCount,
          doneCount = _this$state$pushStatu.doneCount,
          failedCount = _this$state$pushStatu.failedCount,
          stoping = _this$state.stoping;
      return React.createElement(Modal, {
        visible: visible,
        title: '历史流程档案推送',
        onOk: this.handleOk,
        onCancel: this.handleCancel,
        okText: '推送',
        confirmLoading: confirmLoading,
        footer: [React.createElement(Button, {
          key: "back",
          type: "ghost",
          size: "large",
          onClick: this.handleCancel
        }, "\u53D6\u6D88"), React.createElement(Button, {
          key: "submit",
          type: "primary",
          size: "large",
          loading: confirmLoading,
          onClick: this.handleOk
        }, "\u63A8\u9001"), pushing ? React.createElement(Button, {
          key: "stop",
          type: "ghost",
          size: "large",
          onClick: this.stopComfirm,
          loading: stoping
        }, "\u7EC8\u6B62\u63A8\u9001") : null]
      }, React.createElement("div", {
        style: {
          display: 'flex',
          alignItems: 'center'
        }
      }, React.createElement("span", null, "\u9009\u62E9\u8981\u63A8\u9001\u5386\u53F2\u6570\u636E\u7684\u6D41\u7A0B\uFF1A"), React.createElement(WeaBrowser, {
        type: 162,
        title: '选择流程',
        textDecoration: true,
        inputStyle: {
          width: 200
        },
        replaceDatas: datas,
        dataParams: {
          type: 'browser.archive_push_workflow_gq'
        },
        conditionDataParams: {
          fielddbtype: 'browser.archive_push_workflow_gq',
          type: 'browser.archive_push_workflow'
        },
        completeParams: {
          fielddbtype: "browser.archive_push_workflow_gq",
          type: 162
        },
        dataURL: '/api/public/browser/data/161',
        onChange: function onChange(ids, names, datas) {
          _this5.setState({
            datas: datas
          });
        },
        tabsUrl: "/api/common/browser/tab/list?type=",
        isSingle: false,
        isMultCheckbox: true
      }), React.createElement(WeaHelpfulTip, {
        title: '如果查找不到你想要的流程，请确认该流程是否在建模中配置了档案推送',
        style: {
          marginLeft: 10
        }
      })), React.createElement("div", {
        style: {
          padding: 20,
          textAlign: 'center',
          display: pushing ? 'block' : 'none'
        }
      }, React.createElement(Progress, {
        type: "circle",
        percent: (doneCount / totalCount * 100).toFixed(0)
      })), React.createElement("div", {
        style: {
          display: pushing ? 'block' : 'none'
        }
      }, React.createElement("p", null, "\u63A8\u9001\u6D41\u7A0B\u603B\u6570\uFF1A", totalCount), React.createElement("p", null, "\u5DF2\u5B8C\u6210\uFF1A", doneCount), React.createElement("p", {
        style: {
          color: 'red'
        }
      }, "\u63A8\u9001\u9519\u8BEF\uFF1A", failedCount), stoping && React.createElement("p", {
        style: {
          color: 'red'
        }
      }, "\u6B63\u5728\u7EC8\u6B62...")));
    }
  }]);

  return PushHistoryDialog;
}(React.Component);

ecodeSDK.setCom('${appId}', 'PushHistoryDialog', PushHistoryDialog);