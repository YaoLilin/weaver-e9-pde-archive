const {Modal,message,Progress,Button} = antd;
const {WeaBrowser,WeaHelpfulTip,WeaTools} = ecCom;
const {callApi} = WeaTools;


class PushHistoryDialog extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      visible: false,
      confirmLoading:false,
      datas:[],
      pushStatus:{
        pushing:false,
        totalCount:0,
        doneCount:0,
        failedCount:0,
      },
      stoping:false
    };
    this.interval = null;
  }

  componentDidMount() {
    window.pushHistoryDialog = () => this.setState({visible: true});
    this.startCheckPushStatus();
  }

  startCheckPushStatus(){
    if(this.interval == null){
      this.interval = setInterval(() =>{
        this.getPushStatus(); 
      },1000);
    }
  }

  getPushStatus(){
    callApi('/api/secondev/archive/push-history-status','GET').then(result =>{
      if(result.pushing){
        this.setState({confirmLoading:true});
      }else{
        if(this.state.pushStatus.pushing){
          message.success('已全部推送完成，您可以在台账中查看每条流程的推送结果',5);
        }
        this.stopCheckPushStatus();
        this.setState({confirmLoading:false});
      }
      this.setState({pushStatus:result});
    }).catch(e =>{
      this.stopCheckPushStatus();
      message.error('获取推送状态出错',5);
    })
  }

  stopCheckPushStatus() {
    if (this.interval != null) {
      clearInterval(this.interval);
      this.interval = null;
    }
  }

  handleOk = () => {
    const selectedWorkflows = this.getSelectedWorkflows();
    if (selectedWorkflows.length === 0) {
      message.warn('请选择要推送的流程类型');
      return;
    }
    if (this.state.pushStatus.pushing) {
      message.warn('请等待数据推送完成');
      return;
    }
    this.setState({ confirmLoading: true });
    this.startCheckPushStatus();
    callApi('/api/secondev/archive/push-history', 'POST', { workflowIds: selectedWorkflows })
      .then((result) => {
        debugger
        if (result.success !== undefined ) {
          const { message: msg, success, hadPushData } = result;
          if (!success) {
            message.error('推送错误：' + msg, 5);
          } else if (success && !hadPushData) {
            message.info('没有需要推送的历史数据', 5);
          } else {
            message.success('正在后台执行推送，请耐心等待', 5);
          }
        } else {
          message.success('正在后台执行推送，请耐心等待', 5);
        }
      }).catch(e => {
        message.error('推送异常，请联系管理员处理', 5);
        this.setState({ pushStatus: { pushing: false } });
        this.setState({ confirmLoading: false });
      });
  }

  getSelectedWorkflows = ()=>{
    const workflowIds = [];
    this.state.datas.forEach(i => workflowIds.push(i.id));
    return workflowIds.join(',');
  }

  handleCancel =()=>{
    this.setState({visible: false,confirmLoading:false});
  }

  stopComfirm =()=>{
    Modal.confirm({
      title:'终止确认',
      content:'确认终止推送吗？这可能导致某些数据异常',
      onOk: ()=>{
        this.handleStopPush();
      },
      onCancel() {},
    })
  }

  handleStopPush = ()=>{
    this.setState({stoping:true});
    callApi('/api/secondev/archive/stop-history-push','POST').then(()=>{
      message.success('终止完成');
      this.setState({stoping:false});
      this.setState({confirmLoading:false});
      this.setState({pushStatus:{
          pushing:false,
          totalCount:0,
          doneCount:0,
          failedCount:0,
      }})
    }).catch(e =>{
      message.error('终止失败，请联系管理员处理',5);
      this.setState({stoping:false});
    });
    this.stopCheckPushStatus();
    message.info('正在终止推送，这可能需要花费数分钟时间，请耐心等待',5);
  }

  render() {
    const {visible,selectedWorkflow,confirmLoading,datas,pushStatus:{pushing,totalCount,doneCount,failedCount},stoping} = this.state;

    return (
        <Modal visible={visible} title={'历史流程档案推送'} onOk={this.handleOk}
               onCancel={this.handleCancel}
               okText={'推送'} confirmLoading={confirmLoading}
               footer={[
                  <Button key="back" type="ghost" size="large" onClick={this.handleCancel}>取消</Button>,
                  <Button key="submit" type="primary" size="large" loading={confirmLoading} onClick={this.handleOk}>
                    推送
                  </Button>,
                  pushing ? 
                    <Button key="stop" type="ghost" size="large" onClick={this.stopComfirm} loading={stoping}>终止推送</Button> 
                    : null,
                ]}
               >
          <div style={{display:'flex',alignItems:'center'}}>
            <span>选择要推送历史数据的流程：</span>
            <WeaBrowser
                type={162}
                title={'选择流程'}
                textDecoration={true}
                inputStyle={{width: 200}}
                replaceDatas={datas}
                dataParams={
                  {
                    type: 'browser.archive_push_workflow_gq',
                  }
                }
                conditionDataParams={{
                  fielddbtype:'browser.archive_push_workflow_gq',
                  type:'browser.archive_push_workflow'
                }}
                completeParams={{
                  fielddbtype : "browser.archive_push_workflow_gq",
                  type:162
                }}
                dataURL={'/api/public/browser/data/161'}
                onChange={(ids, names, datas) =>{
                  this.setState({datas})
                }}
                tabsUrl={"/api/common/browser/tab/list?type="}
                isSingle={false}
                isMultCheckbox={true}
            />
            <WeaHelpfulTip title={'如果查找不到你想要的流程，请确认该流程是否在建模中配置了档案推送'} style={{marginLeft:10}} />
          </div>
          <div style={{padding:20,textAlign:'center',display:pushing ? 'block' : 'none'}}>
            <Progress type="circle" percent={(doneCount/totalCount*100).toFixed(0)} />
          </div>
          <div style={{display:pushing ? 'block' : 'none'}}>
            <p>推送流程总数：{totalCount}</p>
            <p>已完成：{doneCount}</p>
            <p style={{color:'red'}}>推送错误：{failedCount}</p>
            {stoping &&  <p style={{color:'red'}}>正在终止...</p> }
          </div>
        </Modal>
    )
  }
}

ecodeSDK.setCom('${appId}', 'PushHistoryDialog', PushHistoryDialog)
